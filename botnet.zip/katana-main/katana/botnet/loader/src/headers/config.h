#pragma once

#define HTTP_SERVER "203.159.80.150"
#define HTTP_PORT 80

#define TFTP_SERVER "203.159.80.150"
