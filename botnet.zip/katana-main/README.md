# katana
Katana Botnet, based on the Mirai Botnet.

**Please be aware: I did not create this software! I am merely sharing it with no bad intent for teaching purposes only! Any harm or such you do with it, I hold no responsibility for it!**

#StandWithUkraine
